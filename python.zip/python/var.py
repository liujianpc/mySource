#filename:var.py
w = 5
h = 6
area = w*h
print "area is",area
print("area2 is %d" % area)
