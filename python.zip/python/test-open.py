f = open('dd.txt')
for eachline in f:
    print eachline
f.close()
