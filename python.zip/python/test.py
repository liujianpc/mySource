#morencanshu.py
def shuchu(str,time=5):
    print(str*time)
shuchu("hello",2)
