while 1:
    try:
        n = int(raw_input("input an integer:"))
        print n
      except:
        print "error!try again!"
