f = open('test.txt','r')
for line in f:
    print line.rstrip()
