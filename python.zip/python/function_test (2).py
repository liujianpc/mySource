#functuion_test.py
def grade(grade):
    if grade > 90:
        print("A")
    elif grade >= 80 and grade < 90:
        print("B")
    elif grade >=60 and grade < 80:
        print("C")
    else:
        print("too bad!")
gr = input("������ɼ���")
grade(grad)
