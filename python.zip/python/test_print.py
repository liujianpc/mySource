#test print(shuju,file)
a = [1,2,3,4,5,'liujian']
f = open('test.liujian','a')
print(a,f)
f.close()
