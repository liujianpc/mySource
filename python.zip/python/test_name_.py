#file test_name_.py
if __name__ == '__main__':
    print 'run by itself'
else:
    print "waibu yinyong"
