#variable
l = ['1','2','3','4']
l.extend(['5','6'])
print l
