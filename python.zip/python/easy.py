#easy.py
while 1:
    str = raw_input("ipnut a string:")
    if str == "hello":
        print("rigth!")
        break
else:
    print("done!")
