#fileName:testStr
string = 'I\'m liujian'
if 'l' in string:
    print 'there is a l'
else:
    print 'there is no l'
if string.find('liu'):
    print'have liu'
str1 = ['liujian','mengjian','lijinming','liuyuxuan']
dep = '%'
print dep.join(str1)
if string.startswith('I'):
    print 'yes'
