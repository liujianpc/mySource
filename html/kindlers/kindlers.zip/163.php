<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>网易云音乐外链</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<meta name="煎锅 网易云音乐 外链" content="EverEdit" />
	<meta name="煎锅" content="煎锅 网易云音乐 外链" />
	<meta name="煎锅 网易云音乐 外链" content="煎锅 网易云音乐 外链" />
	<meta name="煎锅 网易云音乐 外链" content="煎锅 网易云音乐 外链" />
	<link href="./163music.css" rel="stylesheet">
	<style type="text/css" media="screen" id="test">
		
	</style>
</head>
<body>
	<h2>查询结果如下</h2>
	<div id="back"><a href="./163music.html">返回搜索页</a></div>
	<p>受到良心谴责，所以每首歌值只给出10个盗链。大家多支持网易云音乐。煎锅作品，请勿举报，谢谢支持</p>	
<?php
	//header("Content-type:text/html;charset=utf-8");
function curl_get($url)
{
    $refer = "http://music.163.com/";
    $header[] = "Cookie: " . "appver=1.5.0.75771;";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($ch, CURLOPT_REFERER, $refer);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}
 
	$url = "http://music.163.com/api/search/get/web?csrf_token=";
	$s = $_POST["search"];
	$limit = 10;

function curl($url, $s, $limit){
     $curl = curl_init();
     $post_data = 'hlpretag=<span class="s-fc7">&hlposttag=</span>&s=' . $s . '&type=1&offset=0&total=true&limit=' . $limit;
     curl_setopt($curl, CURLOPT_URL, $url);
     curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    
     $header = array(
        'Host: music.163.com',
         'Origin: http://music.163.com',
         'User-Agent: Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.90 Safari/537.36',
         'Content-Type: application/x-www-form-urlencoded',
         'Referer: http://music.163.com/search/',
        );
    
     curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    
     curl_setopt($curl, CURLOPT_POST, 1);
     curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
     $src = curl_exec($curl);
     curl_close($curl);
     return $src;
    }
    //根据id获取MP3链接
function get_music_info($music_id)
{
    $url = "http://music.163.com/api/song/detail/?id=" . $music_id . "&ids=%5B" . $music_id . "%5D";
    return curl_get($url);
}
//判断是否输入了歌曲名
if(!$s || !$limit){
     $tempArr = array("code" => -1, "msg" => "请输入歌曲名");
     echo "soory！" . $tempArr["msg"] . "！特么不输入歌曲名，怎么搜啊！！！";
    }
else{
	$ID_array = json_decode(curl($url, $s, $limit),true);//将json转换数组
	//print_r($ID_array);
     //echo curl($url, $s, $limit);
     //根据id获取歌曲信息，包括MP3链接
   // echo get_music_info($ID_array["result"]["songs"][0]["id"]);
   
   echo "<table border='2'>";
   echo "<tr>";
   echo "<td>"."歌曲序号"."</td>";
   echo "<td>"."歌曲名称"."</td>";
   echo "<td>"."歌手"."</td>";
   echo "<td>"."歌曲链接：点击可直接播放或下载，否则复制到迅雷可下载，可用作QQ空间背景音乐"."</td>";
   echo "</tr>";
     for ( $i=0; $i < $limit; $i++ )
     { 
    	$Info_array = json_decode(get_music_info($ID_array["result"]["songs"][$i]["id"]),true);
    	echo "<tr>";
    	echo "<td>".($i+1)."</td>";
     	echo "<td>《".$Info_array["songs"][0]["name"]."》</td>";//输出歌曲名
     	echo "<td>".$Info_array["songs"][0]["artists"][0]["name"]."</td>";//输出歌手名
     	echo "<td><a href='{$Info_array["songs"][0]["mp3Url"]}'>".$Info_array["songs"][0]["mp3Url"]."</a></td>";//输出MP3歌曲链接
     	echo "</tr>";
     	
	 }
	 echo "</table>" ;
 }
?>
<div class="achor">
	<ul>
		
		<li id="blog"><a href="http://www.jiantong.cc">点一下又不会怀孕</a></li>
		<li id="hexo"><a href="http://liujianpc.github.io">看一下也不会怀孕</a></li>
		<li id="home"><a href="http://kindlers.sinaapp.com">带你飞</a></li>
		<li id="wangyi"><a href="http://music.163.com">网易云音乐</a></li>
	</ul>
	
	
	
</div>

</body>
</html>