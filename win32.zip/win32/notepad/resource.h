//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_MAIN                        101
#define IDR_MENU1                       103
#define IDC_OK                          1000
#define IDC_EDIT1                       1004
#define ID_MENUITEM40005                40005
#define ID_OPEN                         40006
#define ID_MENUITEM40007                40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
