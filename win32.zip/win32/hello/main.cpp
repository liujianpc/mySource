#include <windows.h>

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
 	MessageBox(NULL,TEXT("hello"),TEXT("hello"),MB_OK);

	return 0;
}
