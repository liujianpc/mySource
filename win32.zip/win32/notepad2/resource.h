//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_MAIN                        101
#define IDR_MENU1                       104
#define IDC_OK                          1000
#define IDC_EDIT1                       1004
#define ID_OPEN                         40001
#define ID_MENUITEM40002                40002
#define ID_MENUITEM40003                40003
#define ID_MENUITEM40004                40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
