//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_MAIN                        101
#define IDB_BITMAP1                     111
#define IDB_BITMAP2                     112
#define IDR_MENU1                       113
#define IDC_OK                          1000
#define IDC_CANCEL                      1005
#define IDC_EDIT1                       1008
#define IDC_EDIT2                       1009
#define IDC_RADIO1                      1010
#define IDC_RADIO2                      1011
#define IDC_RADIO3                      1017
#define IDC_COMBO1                      1020
#define ID_MENUITEM40001                40001
#define ID_MENUITEM40002                40002
#define ID_MENUITEM40003                40003
#define ID_MENUITEM40005                40005
#define ID_MENUITEM40006                40006
#define ID_MENUITEM40007                40007
#define ID_MENUITEM40008                40008
#define ID_MENUITEM40009                40009
#define ID_MENUITEM40010                40010
#define ID_MENUITEM40011                40011
#define ID_MENUITEM40012                40012
#define ID_MENUITEM40013                40013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
