========================================================================
       WIN32 APPLICATION : DlgBaseProject
========================================================================


AppWizard has created this win32_prj1 application for you.  

This file contains a summary of what you will find in each of the files that
make up your win32_prj1 application.

win32_prj1.cpp
    This is the main application source file.

DlgBaseProject.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.
	

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named win32_prj1.pch and a precompiled types file named StdAfx.obj.


/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.


/////////////////////////////////////////////////////////////////////////////
