#define 	IDM_EXIT		10001
#define 	IDM_ABOUT		10002

#define 	IDC_1		10101
#define 	IDD_ABOUTBOX	10102
